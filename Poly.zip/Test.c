#include <stdio.h>
#include"Poly.h"
#pragma warning (disable : 4996)
#define PolyCreateCheck
#define PolyDestroyCheck
#define PolyFromIntCheck
#define PolyParseCheck
#define PolyFormatCheck
#define PolyReadChek
#define PolyWriteCheck
#define PolyAddCheck
#define PolySubCheck
#define PolyMulCheck
#define PolyMulIntCheck
#define PolyEvaluateCheck
#define PolyElementCheck
int main() {
	FILE* fp;
	poly_t polynomial;
	poly_t poly1;
	poly_t poly2;
	int i, num,x;
	int arr[] = {1,2,3,4};
	char* str;
#ifdef PolyCreateCheck
	polynomial = PolyCreate(arr,4);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ",polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyCreateCheck
#ifdef  PolyFromIntCheck
	polynomial = PolyFromInt(5,1,2,3,4,5);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyFromIntCheck
#ifdef PolyParseCheck
	str = "-x^4 + 14x^2 - 5x + 1";
	polynomial = PolyParse(str);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyParseCheck
#ifdef PolyFormatCheck
	str = PolyFormat(&polynomial);
	printf("%s\n",str);
#endif // PolyFormatCheck
#ifdef PolyReadChek
	fp = fopen("read.txt","rt");
	polynomial = PolyRead(fp);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
	fclose(fp);
#endif // PolyReadChek
#ifdef PolyWriteCheck
	fp = fopen("write.txt","wt");
	PolyWrite(polynomial, fp);
	fclose(fp);
#endif // PolyWriteCheck
#ifdef PolyDestroyCheck
	PolyDestroy(&polynomial);
	if (polynomial.factor == NULL) {
		printf("Polynomial doesn't exist\n");
	}
#endif // PolyDestroyCheck
#ifdef PolyAddCheck
	poly1 = PolyFromInt(4, 12, 0, 3, -5);
	poly2 = PolyFromInt(2, 3, -5);
	polynomial = PolyAdd(poly1, poly2);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyAddCheck
#ifdef PolySubCheck
	poly1 = PolyFromInt(4, 12, 6, 0, -5);
	poly2 = PolyFromInt(2, 3, -5);
	polynomial = PolySub(poly1, poly2);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolySubCheck
#ifdef PolyMulCheck
	poly1 = PolyFromInt(4, 12, 6, 0, -5);
	poly2 = PolyFromInt(2, 3, -5);
	polynomial = PolyMul(poly1, poly2);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyMulCheck
	
#ifdef PolyMulIntCheck
	num = 7;
	poly1 = PolyFromInt(4, 1, 14, -1, 5);
	polynomial = PolyMulInt(poly1, num);
	for (i = 0; i <= polynomial.N; i++) {
		printf("%i ", polynomial.factor[i]);
	}
	printf("\n");
#endif // PolyMulIntCheck
#ifdef PolyEvaluateCheck
	polynomial = PolyFromInt(5, 1, 2, 3, 0, -5);
	x = 3;
	num = PolyEvaluate(polynomial, x);
	printf("Value of polynomial in %i = %i\n",x,num);
#endif // PolyEvaluateCheck
#ifdef PolyElementCheck
	polynomial = PolyFromInt(10, 1, 14, -7, 6, 82, 11, 12, 0, 0, 2);
	i = 5;
	num = PolyElement(polynomial, i);
	printf("%i ",num);
#endif // PolyElementCheck


	return 0;
}